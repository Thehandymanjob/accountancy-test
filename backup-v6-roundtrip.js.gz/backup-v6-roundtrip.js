/* THA v6 lossless IndexedDB staging + reconstruction test.
   Test-only: never reads/writes LocalStorage and never changes application storage mode.
   Requires the schema-v4 test foundation. No production database is referenced.
*/
(function (root) {
  "use strict";
  const DB_NAME = "the_handyman_accountancy_test226";
  const PREFIX = "__tha_v6_roundtrip__:";
  const LEDGERS = ["income", "expenses", "wages", "tools", "food", "materials"];
  const STORES = ["legacySnapshots", "customers", "projects", "invoices", "contracts",
    "accountingEntries", "projectReceipts", "projectExpenses", "workers", "partners",
    "contractors", "companies", "companyJobs", "customExpenseCategories",
    "thirdPartyTransactions", "accountingSettings", "projectMetadata", "recordOrder"];

  const clone = value => JSON.parse(JSON.stringify(value));
  const canonical = value => {
    if (Array.isArray(value)) return value.map(canonical);
    if (value && typeof value === "object") {
      const out = {};
      Object.keys(value).sort().forEach(key => { out[key] = canonical(value[key]); });
      return out;
    }
    return value;
  };
  const equal = (a, b) => JSON.stringify(canonical(a)) === JSON.stringify(canonical(b));
  const assertArray = (value, label) => {
    if (!Array.isArray(value)) throw new Error(label + " must be an array.");
    return value;
  };
  const assertObject = (value, label) => {
    if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error(label + " must be an object.");
    return value;
  };
  function validate(payload) {
    assertObject(payload, "Backup");
    if (payload.app !== "The Handyman Accountancy" || payload.backupType !== "complete-user-data" || payload.version !== 6)
      throw new Error("Expected The Handyman Accountancy complete-user-data backup version 6.");
    const data = assertObject(payload.data, "data"), workspace = assertObject(payload.projects, "projects");
    ["entries", "customers", "invoices", "customExpenseCategories", "thirdPartyTransactions"].forEach(k => assertArray(data[k], "data." + k));
    assertObject(data.settings, "data.settings");
    ["projects", "workers", "partners", "contractors", "companies", "companyJobs"].forEach(k => assertArray(workspace[k], "projects." + k));
    assertObject(workspace.profile, "projects.profile");
    assertArray(payload.contracts, "contracts");
    const allIds = new Map();
    function checkRows(rows, label) {
      rows.forEach((row, index) => {
        assertObject(row, label + "[" + index + "]");
        if (row.id === undefined || row.id === null || String(row.id) === "") throw new Error(label + "[" + index + "] has no id.");
        const id = String(row.id);
        if (allIds.has(id)) throw new Error("Duplicate source ID " + id + " in " + label + " and " + allIds.get(id) + ".");
        allIds.set(id, label);
      });
    }
    ["entries", "customers", "invoices"].forEach(k => checkRows(data[k], "data." + k));
    ["workers", "partners", "contractors", "companies", "companyJobs"].forEach(k => checkRows(workspace[k], "projects." + k));
    checkRows(workspace.projects, "projects.projects");
    checkRows(payload.contracts, "contracts");
    workspace.projects.forEach((project, pi) => {
      LEDGERS.forEach(k => { if (Object.prototype.hasOwnProperty.call(project, k)) assertArray(project[k], "project " + project.id + "." + k); });
      if (Object.prototype.hasOwnProperty.call(project, "subprojects")) assertArray(project.subprojects, "project " + project.id + ".subprojects");
      (project.subprojects || []).forEach((sub, si) => {
        assertObject(sub, "project " + project.id + ".subprojects[" + si + "]");
        if (sub.id === undefined || sub.id === null || String(sub.id) === "") throw new Error("Sub-project is missing its source ID.");
        const id = String(sub.id);
        if (allIds.has(id)) throw new Error("Duplicate source ID " + id + " in sub-project and " + allIds.get(id) + ".");
        allIds.set(id, "sub-project of " + project.id);
        LEDGERS.forEach(k => { if (Object.prototype.hasOwnProperty.call(sub, k)) assertArray(sub[k], "sub-project " + sub.id + "." + k); });
      });
      for (const scope of [project, ...(project.subprojects || [])]) {
        LEDGERS.forEach(k => (scope[k] || []).forEach((row, ri) => {
          assertObject(row, "ledger " + project.id + "/" + k + "[" + ri + "]");
          if (row.id === undefined || row.id === null || String(row.id) === "") throw new Error("Ledger record in " + k + " is missing its source ID.");
          const id = String(row.id);
          if (allIds.has(id)) throw new Error("Duplicate source ID " + id + " in ledger and " + allIds.get(id) + ".");
          allIds.set(id, "ledger " + k);
        }));
      }
    });
    return payload;
  }

  function makePlan(payload, rawText) {
    validate(payload);
    if (typeof rawText !== "string") throw new Error("Original backup text is required for byte/hash verification.");
    const data = payload.data, workspace = payload.projects;
    const plan = Object.fromEntries(STORES.map(name => [name, []]));
    const manifest = {
      id: PREFIX + "manifest", schema: 1, rawByteLength: new Blob([rawText]).size,
      collectionOrder: {}, projectShapes: {}, subprojectShapes: {}, ledgerLinks: {},
      sourceExportedAt: payload.exportedAt, exportedAtPresent: Object.prototype.hasOwnProperty.call(payload, "exportedAt")
    };
    const addRows = (store, rows, collectionPath) => {
      plan[store].push(...rows.map(row => clone(row)));
      manifest.collectionOrder[collectionPath] = rows.map(row => String(row.id));
    };
    addRows("accountingEntries", data.entries, "data.entries");
    addRows("customers", data.customers, "data.customers");
    addRows("invoices", data.invoices, "data.invoices");
    addRows("thirdPartyTransactions", data.thirdPartyTransactions, "data.thirdPartyTransactions");
    addRows("workers", workspace.workers, "projects.workers");
    addRows("partners", workspace.partners, "projects.partners");
    addRows("contractors", workspace.contractors, "projects.contractors");
    addRows("companies", workspace.companies, "projects.companies");
    addRows("companyJobs", workspace.companyJobs, "projects.companyJobs");
    addRows("contracts", payload.contracts, "contracts");

    const categoryRows = data.customExpenseCategories.map((value, index) => ({ id: PREFIX + "category:" + index, value: clone(value), sourceIndex: index }));
    plan.customExpenseCategories.push(...categoryRows);
    manifest.collectionOrder["data.customExpenseCategories"] = categoryRows.map(row => row.id);
    plan.accountingSettings.push({ id: PREFIX + "accounting-settings", settings: clone(data.settings) });
    const workspaceMeta = { id: PREFIX + "project-metadata", profile: clone(workspace.profile),
      presence: Object.fromEntries(["current", "guide", "currentSubproject", "profitReportProjectId"].map(k => [k, Object.prototype.hasOwnProperty.call(workspace, k)])) };
    ["current", "guide", "currentSubproject", "profitReportProjectId"].forEach(key => {
      if (workspaceMeta.presence[key]) workspaceMeta[key] = clone(workspace[key]);
    });
    plan.projectMetadata.push(workspaceMeta);

    const projectRows = [];
    const receiptRows = [], expenseRows = [];
    workspace.projects.forEach(project => {
      const projectId = String(project.id);
      const projectBase = clone(project);
      const projectShape = { arrays: {}, hasSubprojects: Object.prototype.hasOwnProperty.call(project, "subprojects") };
      LEDGERS.forEach(key => {
        projectShape.arrays[key] = Object.prototype.hasOwnProperty.call(project, key);
        delete projectBase[key];
      });
      delete projectBase.subprojects;
      projectRows.push(projectBase);
      manifest.projectShapes[projectId] = projectShape;
      manifest.collectionOrder["projects.project:" + projectId] = [];

      function collectLedger(scope, subprojectId, shapeMap, shapeKey) {
        const shape = shapeMap[shapeKey] || { arrays: {} };
        if (!shape.arrays) shape.arrays = {};
        LEDGERS.forEach(key => {
          shape.arrays[key] = Object.prototype.hasOwnProperty.call(scope, key);
          const rows = scope[key] || [];
          rows.forEach((row, index) => {
            const id = String(row.id);
            const target = key === "income" ? receiptRows : expenseRows;
            target.push(clone(row));
            manifest.ledgerLinks[id] = { parentProjectId: projectId, subprojectId, sourceCollection: key, sourceIndex: index };
          });
        });
        shapeMap[shapeKey] = shape;
      }
      collectLedger(project, null, manifest.projectShapes, projectId);
      const subIds = [];
      (project.subprojects || []).forEach(sub => {
        const subId = String(sub.id), base = clone(sub);
        LEDGERS.forEach(key => delete base[key]);
        projectRows.push(base);
        subIds.push(subId);
        collectLedger(sub, subId, manifest.subprojectShapes, subId);
      });
      manifest.collectionOrder["projects.project:" + projectId] = subIds;
    });
    plan.projects.push(...projectRows);
    plan.projectReceipts.push(...receiptRows);
    plan.projectExpenses.push(...expenseRows);
    manifest.collectionOrder["projects.projects"] = workspace.projects.map(x => String(x.id));
    manifest.collectionOrder["projectReceipts"] = receiptRows.map(x => String(x.id));
    manifest.collectionOrder["projectExpenses"] = expenseRows.map(x => String(x.id));
    manifest.collectionOrder["projects.projectRows"] = projectRows.map(x => String(x.id));
    plan.recordOrder.push(manifest);

    const snapshot = { id: PREFIX + "raw-backup", legacyKey: PREFIX + "raw-backup", present: true,
      raw: rawText, byteLength: manifest.rawByteLength, validJson: true, sha256: null,
      capturedAt: new Date().toISOString() };
    plan.legacySnapshots.push(snapshot);
    return { plan, manifest, snapshot };
  }

  function dbApi() {
    const f = root.HandymanStorageFoundation;
    if (!f || f.databaseName !== DB_NAME || f.schemaVersion !== 4 || typeof f.openDatabase !== "function")
      throw new Error("The v250 schema-v4 test IndexedDB foundation is not loaded.");
    return f;
  }
  function req(request) { return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("IndexedDB request failed."));
  }); }
  function txDone(tx) { return new Promise((resolve, reject) => {
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error || new Error("IndexedDB transaction failed."));
    tx.onabort = () => reject(tx.error || new Error("IndexedDB transaction aborted."));
  }); }
  async function sha256(text) {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
    return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
  }
  async function readStores(db) {
    const out = {};
    for (const name of STORES) {
      const tx = db.transaction([name], "readonly");
      out[name] = await req(tx.objectStore(name).getAll());
    }
    return out;
  }
  function assertEmpty(rows) {
    const occupied = Object.entries(rows).filter(([name, values]) => name !== "auditLog" && values.length > 0);
    if (occupied.length) throw new Error("Staging blocked: destination stores are not empty: " + occupied.map(([name, values]) => name + "=" + values.length).join(", ") + ". Nothing was overwritten.");
  }
  function reconstruct(stores) {
    const manifest = stores.recordOrder.find(row => row.id === PREFIX + "manifest");
    if (!manifest) throw new Error("Round-trip manifest is missing.");
    const ordered = (store, path) => {
      const ids = manifest.collectionOrder[path];
      if (!Array.isArray(ids)) throw new Error("Missing order list: " + path);
      const map = new Map(stores[store].map(row => [String(row.id), row]));
      const result = ids.map(id => map.get(String(id)));
      if (result.some(row => !row)) throw new Error("Missing record while reconstructing " + path);
      return result.map(clone);
    };
    const projectsById = new Map(stores.projects.map(row => [String(row.id), clone(row)]));
    const projectList = ordered("projects", "projects.projects");
    const receipts = new Map(stores.projectReceipts.map(row => [String(row.id), clone(row)]));
    const expenses = new Map(stores.projectExpenses.map(row => [String(row.id), clone(row)]));
    function attachLedger(target, projectId, subId, shape) {
      LEDGERS.forEach(key => {
        const present = shape && shape.arrays && shape.arrays[key];
        const matches = Object.entries(manifest.ledgerLinks).filter(([, link]) => link.parentProjectId === projectId && link.subprojectId === subId && link.sourceCollection === key)
          .sort((a, b) => a[1].sourceIndex - b[1].sourceIndex);
        if (present || matches.length) target[key] = matches.map(([id]) => {
          const source = key === "income" ? receipts.get(id) : expenses.get(id);
          if (!source) throw new Error("Missing ledger record " + id);
          return clone(source);
        });
      });
    }
    const rebuiltProjects = projectList.map(project => {
      const id = String(project.id), shape = manifest.projectShapes[id];
      if (!shape) throw new Error("Project shape metadata missing for " + id);
      attachLedger(project, id, null, shape);
      const subIds = manifest.collectionOrder["projects.project:" + id];
      if (!Array.isArray(subIds)) throw new Error("Sub-project order missing for " + id);
      const subs = subIds.map(subId => {
        const sub = projectsById.get(String(subId));
        if (!sub) throw new Error("Missing sub-project record " + subId);
        const clean = clone(sub), subShape = manifest.subprojectShapes[String(subId)];
        if (!subShape) throw new Error("Sub-project shape metadata missing for " + subId);
        attachLedger(clean, id, String(subId), subShape);
        return clean;
      });
      if (shape.hasSubprojects) project.subprojects = subs;
      return project;
    });
    const settings = stores.accountingSettings.find(row => row.id === PREFIX + "accounting-settings");
    const metadata = stores.projectMetadata.find(row => row.id === PREFIX + "project-metadata");
    if (!settings || !metadata) throw new Error("Settings or workspace metadata record is missing.");
    const workspace = {
      projects: rebuiltProjects,
      workers: ordered("workers", "projects.workers"), partners: ordered("partners", "projects.partners"),
      contractors: ordered("contractors", "projects.contractors"), companies: ordered("companies", "projects.companies"),
      companyJobs: ordered("companyJobs", "projects.companyJobs"), profile: clone(metadata.profile)
    };
    ["current", "guide", "currentSubproject", "profitReportProjectId"].forEach(key => {
      if (metadata.presence[key]) workspace[key] = clone(metadata[key]);
    });
    const categoryRows = ordered("customExpenseCategories", "data.customExpenseCategories");
    const rebuilt = {
      app: "The Handyman Accountancy", backupType: "complete-user-data", version: 6,
      data: {
        entries: ordered("accountingEntries", "data.entries"), customers: ordered("customers", "data.customers"),
        invoices: ordered("invoices", "data.invoices"), customExpenseCategories: categoryRows.map(row => clone(row.value)),
        thirdPartyTransactions: ordered("thirdPartyTransactions", "data.thirdPartyTransactions"), settings: clone(settings.settings)
      },
      projects: workspace, contracts: ordered("contracts", "contracts")
    };
    if (manifest.exportedAtPresent) rebuilt.exportedAt = clone(manifest.sourceExportedAt);
    return rebuilt;
  }
  async function inspectPayload(payload, rawText) {
    const built = makePlan(payload, rawText);
    const sourceImages = [];
    function collect(value, path) {
      if (typeof value === "string" && value.startsWith("data:image/")) sourceImages.push({ path, value });
      else if (Array.isArray(value)) value.forEach((item, index) => collect(item, path + "[" + index + "]"));
      else if (value && typeof value === "object") Object.keys(value).forEach(key => collect(value[key], path + "." + key));
    }
    collect(payload, "backup");
    const imageHashes = await Promise.all(sourceImages.map(async item => ({ path: item.path, sha256: await sha256(item.value), characters: item.value.length })));
    return { built, sourceBytes: new Blob([rawText]).size, sourceSha256: await sha256(rawText), imageHashes,
      normalizedCounts: Object.fromEntries(STORES.map(name => [name, built.plan[name].length])) };
  }
  async function stage(rawText) {
    const payload = JSON.parse(rawText);
    const inspected = await inspectPayload(payload, rawText);
    const f = dbApi(), db = await f.openDatabase();
    try {
      const before = await readStores(db); assertEmpty(before);
      const snapshot = inspected.built.snapshot;
      snapshot.sha256 = inspected.sourceSha256;
      const plan = inspected.built.plan;
      const tx = db.transaction(STORES, "readwrite"), done = txDone(tx);
      for (const storeName of STORES) {
        const store = tx.objectStore(storeName);
        for (const row of plan[storeName]) store.add(storeName === "legacySnapshots" ? snapshot : row);
      }
      await done;
      const after = await readStores(db);
      const reconstructed = reconstruct(after);
      const exact = equal(payload, reconstructed);
      const imageHashes = [];
      function collect(value, path) {
        if (typeof value === "string" && value.startsWith("data:image/")) imageHashes.push({ path, value });
        else if (Array.isArray(value)) value.forEach((item, index) => collect(item, path + "[" + index + "]"));
        else if (value && typeof value === "object") Object.keys(value).forEach(key => collect(value[key], path + "." + key));
      }
      collect(reconstructed, "reconstructed");
      const rebuiltHashes = await Promise.all(imageHashes.map(async item => await sha256(item.value)));
      const sourceImageHashList = inspected.imageHashes.map(item => item.sha256).sort();
      const imagesMatch = JSON.stringify(sourceImageHashList) === JSON.stringify(rebuiltHashes.sort());
      const storedSnapshot = after.legacySnapshots.find(row => row.id === PREFIX + "raw-backup");
      const snapshotMatch = !!storedSnapshot && storedSnapshot.raw === rawText && storedSnapshot.byteLength === inspected.sourceBytes && storedSnapshot.sha256 === inspected.sourceSha256;
      const counts = Object.fromEntries(STORES.map(name => [name, after[name].length]));
      return { ok: exact && imagesMatch && snapshotMatch, exactRoundTrip: exact, imageHashesMatch: imagesMatch,
        rawSnapshotMatch: snapshotMatch, sourceBytes: inspected.sourceBytes, sourceSha256: inspected.sourceSha256,
        imageCount: inspected.imageHashes.length, counts, database: DB_NAME, schemaVersion: 4,
        localStorageAccessed: false, localStorageChanged: false, appCutover: false,
        cleanupAvailable: true, note: "Staged only in isolated test IndexedDB. The application remains on LocalStorage." };
    } catch (error) {
      // A failed post-write verification is not silently cleaned up. The exact owned IDs are in the manifest/snapshot.
      throw error;
    } finally { db.close(); }
  }
  async function audit() {
    const f = dbApi(), db = await f.openDatabase();
    try {
      const stores = await readStores(db);
      const snapshot = stores.legacySnapshots.find(row => row.id === PREFIX + "raw-backup");
      if (!snapshot || typeof snapshot.raw !== "string") throw new Error("Staged raw backup snapshot is missing.");
      const payload = JSON.parse(snapshot.raw), rebuilt = reconstruct(stores);
      const sourceHash = await sha256(snapshot.raw);
      const sourceImages = [], targetImages = [];
      const collect = (value, out) => {
        if (typeof value === "string" && value.startsWith("data:image/")) out.push(value);
        else if (Array.isArray(value)) value.forEach(item => collect(item, out));
        else if (value && typeof value === "object") Object.keys(value).forEach(key => collect(value[key], out));
      };
      collect(payload, sourceImages); collect(rebuilt, targetImages);
      const hashes = async values => Promise.all(values.map(sha256));
      const [a, b] = await Promise.all([hashes(sourceImages), hashes(targetImages)]);
      const exact = equal(payload, rebuilt), imagesMatch = JSON.stringify(a.sort()) === JSON.stringify(b.sort());
      return { ok: exact && imagesMatch && snapshot.sha256 === sourceHash,
        exactRoundTrip: exact, imageHashesMatch: imagesMatch, rawSnapshotHashMatch: snapshot.sha256 === sourceHash,
        sourceImageCount: sourceImages.length, stagedImageCount: targetImages.length,
        counts: Object.fromEntries(STORES.map(name => [name, stores[name].length])),
        localStorageChanged: false, appCutover: false };
    } finally { db.close(); }
  }
  async function cleanup() {
    const f = dbApi(), db = await f.openDatabase();
    try {
      const stores = await readStores(db), snapshot = stores.legacySnapshots.find(row => row.id === PREFIX + "raw-backup");
      const manifest = stores.recordOrder.find(row => row.id === PREFIX + "manifest");
      if (!snapshot || !manifest) throw new Error("Owned staging manifest/snapshot not found. Refusing broad cleanup.");
      const owned = {};
      STORES.forEach(name => { owned[name] = [];
        if (name === "legacySnapshots") owned[name] = [PREFIX + "raw-backup"];
        else if (name === "recordOrder") owned[name] = [PREFIX + "manifest"];
        else if (name === "projects") owned[name] = manifest.collectionOrder["projects.projectRows"] || [];
        else if (name === "projectReceipts") owned[name] = manifest.collectionOrder.projectReceipts || [];
        else if (name === "projectExpenses") owned[name] = manifest.collectionOrder.projectExpenses || [];
        else if (name === "customExpenseCategories") owned[name] = manifest.collectionOrder["data.customExpenseCategories"] || [];
        else if (name === "accountingSettings") owned[name] = [PREFIX + "accounting-settings"];
        else if (name === "projectMetadata") owned[name] = [PREFIX + "project-metadata"];
        else {
          const map = { accountingEntries: "data.entries", customers: "data.customers", invoices: "data.invoices",
            thirdPartyTransactions: "data.thirdPartyTransactions", workers: "projects.workers", partners: "projects.partners",
            contractors: "projects.contractors", companies: "projects.companies", companyJobs: "projects.companyJobs", contracts: "contracts" };
          if (map[name]) owned[name] = manifest.collectionOrder[map[name]] || [];
        }
      });
      const tx = db.transaction(STORES, "readwrite"), done = txDone(tx);
      for (const name of STORES) for (const id of owned[name]) tx.objectStore(name).delete(id);
      await done;
      const remaining = await readStores(db);
      const leftovers = Object.fromEntries(STORES.map(name => [name, owned[name].filter(id => remaining[name].some(row => String(row.id) === String(id))).length]));
      const ok = Object.values(leftovers).every(count => count === 0);
      return { ok, removedOnlyOwnedIds: true, leftovers, localStorageChanged: false, appCutover: false };
    } finally { db.close(); }
  }
  root.HandymanBackupV6RoundTrip = Object.freeze({ validate, makePlan, reconstruct, inspectPayload, stage, audit, cleanup, stores: STORES.slice() });
})(window);
